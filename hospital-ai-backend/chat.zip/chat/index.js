const { createAIClient, processMessage } = require("./aiClient");
const { validateRequestBody, handleError } = require("./helpers");

module.exports = async function (context, req) {
  context.log("Solicitud recibida en /chat");

  try {
    const { userId, userName, message } = validateRequestBody(req);
    const { client, agentId } = await createAIClient();

    const result = await processMessage(client, agentId, userId, userName, message);

    context.res = {
      status: 200,
      headers: { "Content-Type": "application/json" },
      body: {
        status: "success",
        response: result.response,
        threadId: result.threadId,
        runId: result.runId,
        rawMessages: result.rawMessages
      }
    };
  } catch (error) {
    const errResponse = handleError(error);
    context.res = {
      status: 500,
      headers: { "Content-Type": "application/json" },
      body: errResponse
    };
  }
};
